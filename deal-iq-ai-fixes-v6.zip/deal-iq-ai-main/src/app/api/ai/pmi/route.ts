

import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { routedCall, type RouteConfig } from "@/lib/ai/router";
import type { ChatMessage, ProviderId } from "@/lib/ai/providers";
import { getSemanticCache, setSemanticCache } from "@/lib/ai/semantic-cache";
import { buildIndustryContextBlock, getSynergyBenchmark, matchSector } from "@/lib/intelligence/industry";
import { buildPmiDependencyMap } from "@/lib/intelligence/pmi-engine";
import { normalizePrompt, injectDealContext } from "@/lib/ai/utils";
import { estimateCost } from "@/lib/ai/cost-estimator";
import { BIG4_PMI_KIT } from "@/lib/proposal/big4-pmi-templates";
import { buildAdvisoryRules } from "@/lib/ai/advisory-rules";
import { getOrSeed, dealModelToPromptBlock } from "@/lib/intelligence/deal-model";



export async function POST(req: Request) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { checkRateLimit } = await import("@/lib/security");
  const allowed = await checkRateLimit(supabase, "ai_pmi", 10, 60);
  if (!allowed) return NextResponse.json({ error: "Rate limit: 10 requests per minute" }, { status: 429 });

const body = await req.json() as {
    deal_id?: string;
    buyer?: string; target?: string; sector?: string; geography?: string;
    deal_size?: string; synergy_ambition?: string; key_risks?: string;
    public_private?: string; listed?: string; known_issues?: string;
    tsa_needed?: boolean; cross_border?: boolean; notes?: string;
    output_mode?: string;
    tier?: "premium" | "economic" | "offline";
   mandate_type?: string;
    buyer_type?: string;
    ownership_type?: string;
    integration_style?: string;
  };
  const tier = body.tier ?? "premium";

  const {
    buyer = "", target = "", sector = "", geography = "",
    deal_size = "", synergy_ambition = "medium", key_risks = "",
    public_private = "private", listed = "unlisted", known_issues = "",
    tsa_needed = false, cross_border = false, notes = "",
  } = body;

  const matchedSector = matchSector(sector);
  const bench = getSynergyBenchmark(sector);
  const industryCtx = buildIndustryContextBlock(sector, geography);
  const dealCtx = injectDealContext({
    buyer, target, sector, geography,
    dealSize: deal_size, notes: normalizePrompt(notes, 1000),
  });

const admin = createAdminClient();

  // Resolve API key via new multi-key library (with legacy ai_settings fallback)
  const { resolveKey } = await import("@/lib/ai/key-resolver");
  const overrideKeyId = ((body as unknown) as { key_id?: string }).key_id;
  const resolved = await resolveKey(admin, user.id, tier === "economic" ? "economic" : "smart", overrideKeyId);

  if (!resolved.apiKey || resolved.provider === "free") {
    return NextResponse.json({
      error: "No AI provider configured. Open Settings → API Key Library and save at least one key, or mark one as the Smart/Economic default.",
    }, { status: 400 });
  }

  const modelOverride = ((body as unknown) as { model_override?: string }).model_override;

  const cfg: RouteConfig = {
    tier: "smart",
    primaryProvider: resolved.provider as ProviderId,
    primaryKey: resolved.apiKey,
    primaryModel: modelOverride || resolved.model || undefined,
    blockFreeFallback: true,
  };

  // Sector-specific functional emphasis (prevents generic output)
  const sectorFunctions: Record<string, string[]> = {
    "Technology, Media & Telecom": ["Product & Engineering", "Cloud & Infra", "GTM & Sales", "Customer Success", "Data & Analytics", "Talent (engineering retention)"],
    "Financial Services": ["Risk & Compliance", "Core Platform / IT", "Treasury & Capital", "Branch / Channel", "Customer Onboarding", "Regulatory Reporting"],
    "Life Sciences & Healthcare": ["R&D Portfolio", "Regulatory Affairs", "Clinical Operations", "Manufacturing & Supply", "Quality (QMS)", "Commercial / Payer"],
    "Industrials & Manufacturing": ["Plant Footprint", "Procurement & Supply Chain", "Operations / Lean", "EHS", "Engineering / NPI", "Logistics"],
    "Consumer": ["Brand & Marketing", "Store / Channel", "Supply Chain & Inventory", "Pricing & Promotion", "Digital / E-comm", "Category Management"],
    "Energy & Resources": ["Asset Operations", "HSE", "Capex Portfolio", "Trading & Hedging", "Supply Chain", "Workforce / Contractors"],
    "Government & Public Sector": ["Procurement (GovCon)", "Compliance & Audit", "Service Delivery", "IT Modernization", "Workforce", "Stakeholder Mgmt"],
  };
  const fns = sectorFunctions[matchedSector] || sectorFunctions["Technology, Media & Telecom"];

  const systemPrompt = `You are an MBB Post-Merger Integration partner. You are NOT writing a sales pitch. You are NOT writing a deal proposal. You are writing the EXECUTION PLAYBOOK that the IMO Lead will follow Day 1 onward.

DIFFERENTIATION FROM PROPOSAL DOCUMENTS:
- A proposal asks "should we do this deal?" — YOUR job is "now that we've signed, HOW do we execute?"
- Skip strategic rationale, deal thesis, "why us" sections — those belong in proposals.
- Every section must be EXECUTION-FOCUSED with named owners, dates, and measurable outcomes.

ABSOLUTE RULES:
1. NO generic phrases. Every plan item must reference ${matchedSector}-specific operations: ${fns.join(", ")}.
2. Functional plans must be tailored: a SaaS PMI focuses on engineering org, ARR retention, GTM rationalization — NOT on plant footprint or procurement category management.
3. Cross-function dependencies must be explicitly mapped (e.g., "HR cannot announce org structure until Finance completes payroll integration → blocks Day 31").
4. KPI tree must link every workstream to a $ synergy outcome from the synergy benchmark range (cost: ${Math.round(bench.costLow*100)}–${Math.round(bench.costHigh*100)}% of EV; rev: ${Math.round(bench.revLow*100)}–${Math.round(bench.revHigh*100)}% of EV).
5. ${cross_border ? "CROSS-BORDER: include data residency, multi-jurisdiction labor consultation, FX hedging, transfer pricing as explicit workstreams." : ""}
6. ${tsa_needed ? "TSA REQUIRED: include TSA exit milestones in the dependency map; standalone capability ramp must be tracked weekly." : ""}
7. ${listed === "listed" ? "Target is LISTED: add disclosure cadence + market reaction management to communications workstream." : ""}

MANDATORY OUTPUT STRUCTURE — exact ## headings, in this order:

## Integration Strategy & Operating Model
- Integration philosophy (full absorption / best-of-both / hold-separate / standalone) — pick one with rationale
- Target operating model: org structure, decision rights, reporting lines (not generic — specific to ${matchedSector})
- Day-1 governance: IMO charter, SteerCo composition, escalation paths

## Functional Integration Plans
For EACH function below, provide a 4-row mini-table (Workstream Lead | Day-1 Priorities | 30-Day Milestone | 100-Day Outcome):
${fns.map((f, i) => `${i+1}. ${f}`).join("\n")}

## Cross-Function Dependency Map
Table: Predecessor | Successor | Dependency Type | Critical Path? | Slack (days)
MINIMUM 8 dependencies. Show which workstreams cannot start until others complete.

## Day-0 / Day-1 / 100-Day Plan (Execution-Grade)
Three sub-tables with date-anchored deliverables:
### Day 0 (Sign to Close)
| Action | Owner | Deadline | Output |

### Day 1 (Close)
| Action | Owner | Hour | Output |

### Days 2-100
| Wave (Days) | Action | Owner | KPI |
Cover Days 1-30 (Stabilize) / 31-60 (Integrate) / 61-100 (Accelerate) — minimum 4 actions per wave.

## KPI Tree (Synergy → Workstream → Metric)
Hierarchical table linking every $ synergy commitment to a specific workstream metric and weekly tracking owner.
Format: Synergy Bucket → Workstream → Leading Indicator → Lagging Indicator → Owner → Weekly Target

## Risk Register & Mitigation
Table: Risk | Workstream | Probability (%) | $ Impact | Early Warning Signal | Mitigation Owner | Trigger Action
MINIMUM 8 risks — sector-specific, not generic. Include known issue: "${known_issues || "none flagged"}".

## IMO Operating Cadence
- Daily standup (Days 1-30): who, when, format
- Weekly workstream reviews: tracker, escalation triggers
- Bi-weekly SteerCo: agenda, materials, decisions
- Monthly Board update: KPI dashboard, synergy capture vs plan

QUALITY CONTROL:
- Total length 1200-1800 words
- Every owner is a specific role (not "the team")
- Every milestone has a date or day-number
- Zero generic strategy filler
- Output should be directly executable by an IMO PMO
CONTENT BACKBONE — Use this Big4 PMI kit as content reference. Tailor specifics to the deal facts above:
${BIG4_PMI_KIT}`;
  const advisoryRules = buildAdvisoryRules({
    mandateType: body.mandate_type,
    buyerType: body.buyer_type,
    ownershipType: body.ownership_type,
    integrationStyle: body.integration_style,
    sector,
  });

  // Load canonical Deal Model — single source of truth across modules
  let dealModelBlock = "";
  if (body.deal_id) {
    const dm = await getOrSeed(supabase, {
      deal_id: body.deal_id,
      user_id: user.id,
      buyer, target, sector, geography,
      deal_size_input: deal_size,
      buyer_type: body.buyer_type,
      ownership_type: body.ownership_type,
    });
    dealModelBlock = dealModelToPromptBlock(dm);
  }


  const finalSystemPrompt = systemPrompt + `

# CANONICAL DEAL MODEL DISCIPLINE (CRITICAL)

The user message contains a CANONICAL DEAL MODEL block at the top. That block is the SINGLE SOURCE OF TRUTH for this deal across all modules (proposal, PMI, synergy, TSA).

Rules:
1. EVERY dollar/INR/currency figure in your output MUST match the canonical model exactly. Do not re-compute, do not round differently, do not change currencies.
2. If the canonical model lists initiatives, risks, regulatory filings, or comparables BY NAME, cite them by those exact names. Do not invent new ones.
3. If a section requires DEPTH that the canonical model does not yet provide (e.g. "List 8 cost initiatives totaling the canonical run-rate"), derive that depth — but the SUM must equal the canonical run-rate, not exceed it.
4. If you believe the canonical numbers are wrong, do NOT change them. Note the disagreement in a "Modeling Note" subsection so the partner can review and override via the Deal Model UI.
5. Currency: report in the canonical model's primary_currency. Do not switch currencies mid-document.

This rule is more important than any other formatting requirement. Coherence across modules is non-negotiable for an MBB-grade deliverable.`;
  
  const userPrompt = [
    dealModelBlock,
    dealCtx,
    industryCtx,
    `Synergy ambition: ${synergy_ambition}`,
    `Public/Private: ${public_private} · ${listed}`,
    `Cross-border: ${cross_border ? "YES" : "NO"} · TSA needed: ${tsa_needed ? "YES" : "NO"}`,
    key_risks ? `Client-flagged risks: ${key_risks}` : "",
    known_issues ? `Known issues: ${known_issues}` : "",
  ].filter(Boolean).join("\n");
  const dependencyMap = buildPmiDependencyMap();
  const messages: ChatMessage[] = [
     // Stable across calls for the same mandate type — provider adapter applies caching where supported.
    { role: "system", stable: true, content: finalSystemPrompt + "\n\n=== DEAL-SPECIFIC RULES ===\n" + advisoryRules },
    { role: "user", content: `${userPrompt}

System dependency map (must explicitly cover): ${JSON.stringify(dependencyMap)}` },
  ];

  const cached = getSemanticCache({ userId: user.id, module: "pmi", messages, salt: `${cfg.primaryProvider}:${cfg.primaryModel ?? "auto"}` });
  if (cached) {
    return NextResponse.json({
      content: cached.content,
      provider: cached.provider ?? cfg.primaryProvider,
      model: cached.model ?? cfg.primaryModel,
      cached: true,
      semanticSimilarity: Number(cached.similarity.toFixed(3)),
    });
  }

  try {
    // Groq free-tier TPM safety: swap to a smaller model if the prompt exceeds Llama 3.3 70B's 12K token cap
  const estimatedTokens = messages.reduce((acc, m) => acc + Math.ceil(m.content.length / 4), 0);
  if (cfg.primaryProvider === "groq" && estimatedTokens > 11000 && cfg.primaryModel?.includes("70b")) {
    cfg.primaryModel = "llama-3.1-8b-instant";
  }
    const result = await routedCall(cfg, messages, 6000);
   if (result.provider === "free" || result.model === "rules-v1") {
      return NextResponse.json({
        error: `PMI AI failed. Real reason: ${result.lastError ?? "unknown"}. Provider: ${cfg.primaryProvider}/${cfg.primaryModel ?? "auto"}.`,
      }, { status: 500 });
    }

    setSemanticCache({ userId: user.id, module: "pmi", messages, content: result.text, provider: result.provider, model: result.model, salt: `${cfg.primaryProvider}:${cfg.primaryModel ?? "auto"}` });

    const inputTokens = result.inputTokens ?? 0;
    const outputTokens = result.outputTokens ?? 0;
    const { cost } = estimateCost(result.provider, inputTokens, outputTokens);

    await admin.from("ai_outputs").insert({
      user_id: user.id,
      module: "pmi",
      buyer, target, sector, geography, deal_size,
      tier, provider: result.provider, model: result.model,
      input_tokens: inputTokens, output_tokens: outputTokens, cost_estimate_usd: cost,
      content: result.text,
      meta: {
        synergy_ambition, public_private, listed,
        tsa_needed, cross_border, output_mode: body.output_mode ?? "narrative",
        key_risks, known_issues,
      },
    });

    return NextResponse.json({
      content: result.text,
      provider: result.provider,
      model: result.model,
      viaFallback: result.viaFallback,
      tokens: { input: inputTokens, output: outputTokens, cost },
    });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
